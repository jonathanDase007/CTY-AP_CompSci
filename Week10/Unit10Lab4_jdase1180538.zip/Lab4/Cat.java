public class Cat extends Pets{
    public Cat(int weight, int age, String name){
        super(weight, age, name);
    }

    public String Talk(){
        return "Meow";
    }

}
