public class Dog extends Pets{
    public Dog(double weight, int age, String name){
        super(weight, age, name);
    }

    public String Talk(){
        return "bow wow";
    }


}
