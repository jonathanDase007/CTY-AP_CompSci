import java.util.*;

public class Unit4Lab3C {

    public static void main(String[] args){

        Scanner input = new Scanner(System.in);
        System.out.println("Enter 10 numbers and this program will sort them by values");

        //defined variables
        int counter = 0;

        System.out.print("Number: ");
        int c  = input.nextInt();
        int smallest = c;
        int largest = c;
        

        do{
            System.out.print("Number: ");
            int number = input.nextInt();

            if (number > largest){
                largest = number;
            }
            else if (number < smallest){
                smallest = number;
            }
            counter ++;
        }while(counter < 9);

        System.out.println("You entered: " + counter + " numbers and the highest was " + largest + " and the smallest was " 
        + smallest);
    
    }
}
