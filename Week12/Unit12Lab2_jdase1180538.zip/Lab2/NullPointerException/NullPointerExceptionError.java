public class NullPointerExceptionError {
    public static void main(String[] args){
        String paul = null;
        System.out.println(paul.charAt(0));
    }

}