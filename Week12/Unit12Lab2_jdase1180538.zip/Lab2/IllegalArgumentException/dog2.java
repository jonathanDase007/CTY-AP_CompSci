public class dog2 {
    public dog2(int j){

    }
}
