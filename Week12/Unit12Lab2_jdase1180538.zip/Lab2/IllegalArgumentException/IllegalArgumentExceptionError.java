public class IllegalArgumentExceptionError {
    public static void main(String[] args){
        dog2 x = new dog2(2);
    }
}
