class ArrayIndexOutOfBoundsExceptionError{
    public static void main(String[] args){
        char[] x = {'a','b','c','d','e'};
        System.out.println(x[7]);

    }
}