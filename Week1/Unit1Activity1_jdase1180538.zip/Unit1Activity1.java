public class Unit1Activity1 {
    /**This is the docstring that explains the purpose of
     * Unit1Acitvity1. It does nothing incase you are wondering
     * @author jonathanDase
     */
}
