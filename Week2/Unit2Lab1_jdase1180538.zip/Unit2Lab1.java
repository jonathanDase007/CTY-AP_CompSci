public class Unit2Lab1{
    /** This class defines all acsii libary for most keyboard inputs
     * 
     */
    public static void main(String[] args){
        //Letters Lowercase
        System.out.printf("The charecter %s has a value of %d \n", 'a', ((int) 'a'));
        System.out.printf("The charecter %s has a value of %d \n", 'b', ((int) 'b'));
        System.out.printf("The charecter %s has a value of %d \n", 'c', ((int) 'c'));
        System.out.printf("The charecter %s has a value of %d \n", 'd', ((int) 'd'));
        System.out.printf("The charecter %s has a value of %d \n", 'e', ((int) 'e'));
        System.out.printf("The charecter %s has a value of %d \n", 'f', ((int) 'f'));
        System.out.printf("The charecter %s has a value of %d \n", 'g', ((int) 'g'));
        System.out.printf("The charecter %s has a value of %d \n", 'h', ((int) 'h'));
        System.out.printf("The charecter %s has a value of %d \n", 'i', ((int) 'i'));
        System.out.printf("The charecter %s has a value of %d \n", 'j', ((int) 'j'));
        System.out.printf("The charecter %s has a value of %d \n", 'k', ((int) 'k'));
        System.out.printf("The charecter %s has a value of %d \n", 'l', ((int) 'l'));
        System.out.printf("The charecter %s has a value of %d \n", 'm', ((int) 'm'));
        System.out.printf("The charecter %s has a value of %d \n", 'n', ((int) 'n'));
        System.out.printf("The charecter %s has a value of %d \n", 'o', ((int) 'o'));
        System.out.printf("The charecter %s has a value of %d \n", 'p', ((int) 'p'));
        System.out.printf("The charecter %s has a value of %d \n", 'q', ((int) 'q'));
        System.out.printf("The charecter %s has a value of %d \n", 'r', ((int) 'r'));
        System.out.printf("The charecter %s has a value of %d \n", 's', ((int) 's'));
        System.out.printf("The charecter %s has a value of %d \n", 't', ((int) 't'));
        System.out.printf("The charecter %s has a value of %d \n", 'u', ((int) 'u'));
        System.out.printf("The charecter %s has a value of %d \n", 'v', ((int) 'v'));
        System.out.printf("The charecter %s has a value of %d \n", 'w', ((int) 'w'));
        System.out.printf("The charecter %s has a value of %d \n", 'x', ((int) 'x'));
        System.out.printf("The charecter %s has a value of %d \n", 'y', ((int) 'y'));
        System.out.printf("The charecter %s has a value of %d \n", 'z', ((int) 'z'));
        System.out.println(' ');

        //Letters Uppercase
        System.out.printf("The charecter %s has a value of %d \n", 'A', ((int) 'A'));
        System.out.printf("The charecter %s has a value of %d \n", 'B', ((int) 'B'));
        System.out.printf("The charecter %s has a value of %d \n", 'C', ((int) 'C'));
        System.out.printf("The charecter %s has a value of %d \n", 'D', ((int) 'D'));
        System.out.printf("The charecter %s has a value of %d \n", 'E', ((int) 'E'));
        System.out.printf("The charecter %s has a value of %d \n", 'F', ((int) 'F'));
        System.out.printf("The charecter %s has a value of %d \n", 'G', ((int) 'G'));
        System.out.printf("The charecter %s has a value of %d \n", 'H', ((int) 'H'));
        System.out.printf("The charecter %s has a value of %d \n", 'I', ((int) 'I'));
        System.out.printf("The charecter %s has a value of %d \n", 'J', ((int) 'J'));
        System.out.printf("The charecter %s has a value of %d \n", 'K', ((int) 'K'));
        System.out.printf("The charecter %s has a value of %d \n", 'L', ((int) 'L'));
        System.out.printf("The charecter %s has a value of %d \n", 'M', ((int) 'M'));
        System.out.printf("The charecter %s has a value of %d \n", 'N', ((int) 'N'));
        System.out.printf("The charecter %s has a value of %d \n", 'O', ((int) 'O'));
        System.out.printf("The charecter %s has a value of %d \n", 'P', ((int) 'P'));
        System.out.printf("The charecter %s has a value of %d \n", 'Q', ((int) 'Q'));
        System.out.printf("The charecter %s has a value of %d \n", 'R', ((int) 'R'));
        System.out.printf("The charecter %s has a value of %d \n", 'S', ((int) 'S'));
        System.out.printf("The charecter %s has a value of %d \n", 'T', ((int) 'T'));
        System.out.printf("The charecter %s has a value of %d \n", 'U', ((int) 'U'));
        System.out.printf("The charecter %s has a value of %d \n", 'V', ((int) 'V'));
        System.out.printf("The charecter %s has a value of %d \n", 'W', ((int) 'W'));
        System.out.printf("The charecter %s has a value of %d \n", 'X', ((int) 'X'));
        System.out.printf("The charecter %s has a value of %d \n", 'Y', ((int) 'Y'));
        System.out.printf("The charecter %s has a value of %d \n", 'Z', ((int) 'Z'));
        System.out.println(' ');

        //Digits 0-9
        System.out.printf("The charecter %s has a value of %d \n", '0', ((int) '0'));
        System.out.printf("The charecter %s has a value of %d \n", '1', ((int) '1'));
        System.out.printf("The charecter %s has a value of %d \n", '2', ((int) '2'));
        System.out.printf("The charecter %s has a value of %d \n", '3', ((int) '3'));
        System.out.printf("The charecter %s has a value of %d \n", '4', ((int) '4'));
        System.out.printf("The charecter %s has a value of %d \n", '5', ((int) '5'));
        System.out.printf("The charecter %s has a value of %d \n", '6', ((int) '6'));
        System.out.printf("The charecter %s has a value of %d \n", '7', ((int) '7'));
        System.out.printf("The charecter %s has a value of %d \n", '8', ((int) '8'));
        System.out.printf("The charecter %s has a value of %d \n", '9', ((int) '9'));
        System.out.println(' ');

        //Symboles inlcuding blank space
        System.out.printf("The charecter %s has a value of %d \n", '+', ((int) '+'));
        System.out.printf("The charecter %s has a value of %d \n", '-', ((int) '-'));
        System.out.printf("The charecter %s has a value of %d \n", '_', ((int) '_'));
        System.out.printf("The charecter %s has a value of %d \n", '=', ((int) '='));
        System.out.printf("The charecter %s has a value of %d \n", '&', ((int) '&'));
        System.out.printf("The charecter %s has a value of %d \n", '@', ((int) '@'));
        System.out.printf("The charecter %s has a value of %d \n", '#', ((int) '#'));
        System.out.printf("The charecter %s has a value of %d \n", '$', ((int) '$'));
        System.out.printf("The charecter %s has a value of %d \n", '?', ((int) '?'));
        System.out.printf("The charecter %s has a value of %d \n", '>', ((int) '>'));
        System.out.printf("The charecter %s has a value of %d \n", '<', ((int) '<'));
        System.out.printf("The charecter %s has a value of %d \n", '|', ((int) '|'));
        System.out.printf("The charecter %s has a value of %d \n", '!', ((int) '!'));
        System.out.printf("The charecter %s has a value of %d \n", '~', ((int) '~'));
        System.out.printf("The charecter %s has a value of %d \n", ' ', ((int) ' '));
        System.out.println(' ');
    }
}